from tkinter import *
import Engine

#INITAILS-------------------------------------------------
kuva = 0
current_player = ""
current_team = ""
node = ""

def main():
    try:
        #ESSENTAILS-------------------------------------------
        player_list = Engine.set_list()
        global current_team
        global current_player
        current_player = player_list[0][0]
        current_team = player_list[0][1]
        global node
        node = player_list[0][1]

        #FUNCTIONS--------------------------------------------
        def out():
            global kuva
            kuva = kuva + 1
            global current_team
            global current_player
            current_player = player_list[kuva][0]
            current_team = player_list[kuva][1]

            t1.delete("1.0", END)
            t1.insert(END, current_team)
            t2.delete("1.0", END)
            t2.insert(END, current_player)

        def press(num):
            current_score = Engine.fetch_runs(current_player) + num
            Engine.update_runs(current_score,current_player)
            t3.delete("1.0", END)
            t3.insert(END, str(current_score))
            total_score = Engine.score(current_team)
            t4.delete("1.0", END)
            t4.insert(END, str(total_score))
            t5.delete("1.0", END)
            t5.insert(END, "Match in progress.")

        def scoreboard(node):
            scores = Engine.match_result(node)
            junk_list = Engine.team_names()
            team_1 = junk_list[0][0]
            team_2 = junk_list[len(junk_list)-1][0]
            if scores[0] > scores[1]:
                feedback = team_1 + " wins the match by " + str(scores[0][0][0]-scores[1][0][0]) + " runs."
            elif scores[0] == scores[1]:
                feedback = "The match ended in a draw."
            else:
                feedback = team_2 + " wins the match by " + str(scores[1][0][0] - scores[0][0][0]) + " runs."
            print(scores)
            notice = "MATCH OVER"
            t1.delete("1.0", END)
            t1.insert(END, notice)
            t2.delete("1.0", END)
            t2.insert(END, notice)
            t3.delete("1.0", END)
            t3.insert(END, notice)
            t4.delete("1.0", END)
            t4.insert(END, notice)
            t5.delete("1.0", END)
            t5.insert(END, feedback)

        #[WINDOW OPEN]---------------------------------------------------
        new = Tk()
        new.wm_title("Match time")

        #LABELS-----------------------------------------------
        lab1 = Label(new, text="Team")
        lab1.grid(row=0, column=0, pady=3)

        lab2 = Label(new, text="Batsman")
        lab2.grid(row=1, column=0, pady=3)

        lab3 = Label(new, text="Runs -")
        lab3.grid(row=5, column=0, pady=3)

        lab4 = Label(new, text="TOTAL -")
        lab4.grid(row=6, column=0, pady=3)

        lab5 = Label(new,text="Status -")
        lab5.grid(row=7, column=0, pady=7)

        #TEXTBOXES--------------------------------------------
        t1 = Text(new, height=1, width=16)
        t1.grid(row=0, column=1)

        t2 = Text(new, height=1, width=16)
        t2.grid(row=1, column=1)

        t3 = Text(new, height=1, width=16)
        t3.grid(row=5, column=1)

        t4 = Text(new, height=1, width=16)
        t4.grid(row=6, column=1)

        t5 = Text(new, height=2, width=16)
        t5.grid(row=7, column=1,pady=5)

        t1.insert(END, current_team)
        t2.insert(END, current_player)

        #BUTTONS----------------------------------------------
        bt1=Button(new,text="One",width=7,command=lambda: press(1))
        bt1.grid(row=2,column=0,padx=5,pady=5)

        bt2=Button(new, text="Two",width=7,command=lambda: press(2))
        bt2.grid(row=2, column=1,padx=5,pady=5)

        bt3=Button(new, text="Three",width=7,command=lambda: press(3))
        bt3.grid(row=2, column=2,padx=5,pady=5)

        bt4=Button(new, text="Four",width=7,command=lambda: press(4))
        bt4.grid(row=3, column=0,padx=5,pady=5)

        bt5=Button(new, text="Six",width=7,command=lambda: press(6))
        bt5.grid(row=3, column=1,padx=5,pady=5)

        bt6=Button(new, text="Wide",width=7,command=lambda: press(1))
        bt6.grid(row=3, column=2,padx=5,pady=5)

        bt7=Button(new, text="No Ball",width=7,command=lambda: press(0))
        bt7.grid(row=4, column=0,padx=5,pady=5)

        bt8=Button(new, text="OUT",width=7,command=out)
        bt8.grid(row=4, column=1,padx=5,pady=5)

        bt9 = Button(new, text="Done.", width=7, command=lambda: scoreboard(node))
        bt9.grid(row=9, column=1, padx=5, pady=5)

        new.mainloop()
        #[WINDOW CLOSE]--------------------------------------------------

    except IndexError:
        pass
