from tkinter import *
import Engine
import GUI_Page2

#FUNCTIONS------------------------------------------------
def get_selected_row(event):
    try:
        global selected_tuple
        index = list1.curselection()[0]
        selected_tuple = list1.get(index)
        e1.delete(0, END)
        e1.insert(END, selected_tuple[1])
        e2.delete(0, END)
        e2.insert(END, selected_tuple[2])
    except IndexError:
        pass

def view_command():
    list1.delete(0,END)
    for row in Engine.view():
        list1.insert(END,row)

def search_command():
    list.delete(0,END)
    for row in Engine.search(team_name.get(),player_name.get()):
        list1.insert(END,row)

def add_command():
    Engine.add(team_name.get(),player_name.get())
    list1.delete(0,END)
    list1.insert(END,(player_name.get() + " added to team " + team_name.get() + "."))

def delete_command():
    Engine.delete(selected_tuple[0])

def clear_command():
    Engine.clear()

def combine_funcs(*funcs):
    def combined_func(*args, **kwargs):
        for f in funcs:
            f(*args, **kwargs)
    return combined_func

def next_command():
    GUI_Page2.main()

#[WINDOW OPEN]-------------------------------------------------------
window = Tk()

window.wm_title("Cricket Simulator")

#LABELS---------------------------------------------------
l1=Label(window,text="Team")
l1.grid(row=0,column=0,pady=3)

l2=Label(window,text="Player")
l2.grid(row=1,column=0,pady=3)

#ENTRIES--------------------------------------------------
team_name=StringVar()
e1=Entry(window,textvariable=team_name)
e1.grid(row=0,column=1,columnspan=2)

player_name=StringVar()
e2=Entry(window,textvariable=player_name)
e2.grid(row=1,column=1,columnspan=2)

#LISTBOX--------------------------------------------------
list1=Listbox(window,height=6,width=35)
list1.grid(row=2,column=0,rowspan=7,columnspan=2,pady=3,padx=3)

sb1=Scrollbar(window)
sb1.grid(row=2,column=2,rowspan=7)

list1.configure(yscrollcommand=sb1.set)
sb1.configure(command=list1.yview)

list1.bind('<<ListboxSelect>>',get_selected_row)

#BUTTONS--------------------------------------------------
b1=Button(window,text="Add Player",width=12,command=add_command)
b1.grid(row=0,column=3,pady=3,padx=5)

b2=Button(window,text="Delete Player",width=12,command=delete_command)
b2.grid(row=1,column=3,pady=3,padx=5)

b3=Button(window,text="View All",width=12,command=view_command)
b3.grid(row=2,column=3,pady=3,padx=5)

b4=Button(window,text="Search",width=12,command=search_command)
b4.grid(row=3,column=3,pady=3,padx=5)

b5=Button(window,text="Clear",width=12,command=clear_command)
b5.grid(row=4,column=3,pady=3,padx=5)

b6=Button(window,text="Next>",width=12,command=combine_funcs(window.destroy, next_command))
b6.grid(row=7,column=3,pady=3,padx=5)

window.mainloop()
#[WINDOW CLOSE]------------------------------------------------------