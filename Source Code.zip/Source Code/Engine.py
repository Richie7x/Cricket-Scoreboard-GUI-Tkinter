import sqlite3

def connect():
    conn=sqlite3.connect("Cricket.db")
    cur=conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS match (id INTEGER PRIMARY KEY, team text, name text, runs integer)")
    conn.commit()
    conn.close()

def add(team,player):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO match VALUES (NULL,?,?,0)",(team,player))
    conn.commit()
    conn.close()

def view():
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM match")
    rows=cur.fetchall()
    conn.close()
    return rows

def search(team="",player=""):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM match WHERE team=? OR player=?",(team,player))
    rows = cur.fetchall()
    conn.close()
    return rows

def delete(id):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM match WHERE id=?", (id,))
    conn.commit()
    conn.close()

def clear():
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("DELETE FROM match")
    conn.commit()
    conn.close()

def set_list():
        conn = sqlite3.connect("Cricket.db")
        cur = conn.cursor()
        cur.execute("SELECT name,team FROM match")
        rows = cur.fetchall()
        conn.close()
        return rows

def fetch_runs(player_name):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT runs FROM match WHERE name=?",(player_name,))
    rows = cur.fetchall()
    conn.close()
    return rows[0][0]

def update_runs(runs,player_name):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("UPDATE match SET runs=? WHERE name=?",(runs,player_name))
    conn.commit()
    conn.close()

def score(team_name):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT SUM(runs) FROM match WHERE team=?", (team_name,))
    rows = cur.fetchall()
    conn.close()
    return rows[0][0]

def match_result(node):
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT SUM(runs) FROM match WHERE team=?", (node,))
    team_one = cur.fetchall()
    cur2 = conn.cursor()
    cur2.execute("SELECT SUM(runs) FROM match WHERE team!=?", (node,))
    team_two =cur2.fetchall()
    conn.close()
    return (team_one,team_two)

def team_names():
    conn = sqlite3.connect("Cricket.db")
    cur = conn.cursor()
    cur.execute("SELECT team FROM match")
    rows = cur.fetchall()
    conn.close()
    return rows

connect()